var group__group__bsp__pins =
[
    [ "Communication Pins", "group__group__bsp__pins__comm.html", "group__group__bsp__pins__comm" ]
];