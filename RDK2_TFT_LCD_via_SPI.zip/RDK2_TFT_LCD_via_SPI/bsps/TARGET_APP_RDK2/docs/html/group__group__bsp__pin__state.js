var group__group__bsp__pin__state =
[
    [ "CYBSP_LED_STATE_ON", "group__group__bsp__pin__state.html#gaedfd071923034a335d143b7b64579169", null ],
    [ "CYBSP_LED_STATE_OFF", "group__group__bsp__pin__state.html#ga31577fad7e20fcb174e2ecbea2dd063e", null ],
    [ "CYBSP_BTN_PRESSED", "group__group__bsp__pin__state.html#ga7778aac7809929e1032f406b59cbad90", null ],
    [ "CYBSP_BTN_OFF", "group__group__bsp__pin__state.html#gafb9176679302bc5b2e002ad7caa56b09", null ]
];