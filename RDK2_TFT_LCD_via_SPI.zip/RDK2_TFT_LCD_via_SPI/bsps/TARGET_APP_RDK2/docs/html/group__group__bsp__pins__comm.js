var group__group__bsp__pins__comm =
[
    [ "CYBSP_SWDIO", "group__group__bsp__pins__comm.html#ga9fba070d4040d6aa4f3e429bdfc38946", null ],
    [ "CYBSP_SWDCK", "group__group__bsp__pins__comm.html#ga8f50aad29445466679abdcc75dcd9796", null ],
    [ "CYBSP_SWO", "group__group__bsp__pins__comm.html#ga83425838dc05860473aebf66214ed9d3", null ]
];